package com.checkers;

public class AppTest {
}
