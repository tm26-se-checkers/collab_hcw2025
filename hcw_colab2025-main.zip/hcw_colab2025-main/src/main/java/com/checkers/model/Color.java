package com.checkers.model;

public enum Color { WHITE, BLACK }
